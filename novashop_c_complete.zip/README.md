# NovaShop — C + HTML + CSS + JavaScript

Một shop demo hoàn chỉnh chạy local bằng web server C.

## Chạy trên Linux / Arch Linux

```bash
gcc server.c -o server
./server
```

Mở trình duyệt tại:

http://localhost:8080

## Có sẵn
- Giao diện responsive
- Hero/banner hình ảnh
- Danh mục
- Flash sale + đồng hồ đếm ngược
- Lọc sản phẩm
- Tìm kiếm sản phẩm
- Giỏ hàng
- Tăng/giảm/xóa sản phẩm
- Lưu giỏ hàng bằng localStorage
- Toast notification
- Trang checkout demo
- Web server HTTP tự viết bằng C

## Lưu ý
Ảnh sản phẩm đang lấy từ Unsplash qua Internet để website có hình ảnh đẹp. Nếu muốn chạy hoàn toàn offline, tải ảnh về `public/images/` và đổi URL trong `app.js`.

Đây là nền tảng frontend + HTTP server C, chưa phải hệ thống thương mại điện tử production. Để triển khai thật cần thêm HTTPS, database, tài khoản, xác thực, API, thanh toán, quản trị, kiểm tra input và bảo mật.
