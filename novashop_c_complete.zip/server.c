#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define PORT 8080
#define BUF_SIZE 8192

void send_file(int client, const char *path, const char *type) {
    FILE *f = fopen(path, "rb");
    if (!f) {
        const char *msg = "HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\n\r\n404 Not Found";
        send(client, msg, strlen(msg), 0);
        return;
    }

    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    rewind(f);

    char header[512];
    int h = snprintf(header, sizeof(header),
        "HTTP/1.1 200 OK\r\nContent-Type: %s\r\nContent-Length: %ld\r\n"
        "Connection: close\r\n\r\n", type, size);
    send(client, header, h, 0);

    char buf[4096];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), f)) > 0)
        send(client, buf, n, 0);
    fclose(f);
}

void handle(int client) {
    char req[BUF_SIZE] = {0};
    recv(client, req, sizeof(req)-1, 0);

    char method[16], path[1024];
    sscanf(req, "%15s %1023s", method, path);

    if (strcmp(method, "GET") != 0) {
        const char *msg = "HTTP/1.1 405 Method Not Allowed\r\nContent-Type: text/plain\r\n\r\nMethod Not Allowed";
        send(client, msg, strlen(msg), 0);
        return;
    }

    if (strcmp(path, "/") == 0) send_file(client, "public/index.html", "text/html; charset=utf-8");
    else if (strcmp(path, "/style.css") == 0) send_file(client, "public/style.css", "text/css");
    else if (strcmp(path, "/app.js") == 0) send_file(client, "public/app.js", "application/javascript");
    else {
        char full[1200];
        snprintf(full, sizeof(full), "public%s", path);
        if (strstr(path, "..")) {
            const char *msg = "HTTP/1.1 403 Forbidden\r\n\r\nForbidden";
            send(client, msg, strlen(msg), 0);
        } else {
            const char *ext = strrchr(path, '.');
            const char *type = "application/octet-stream";
            if (ext && strcmp(ext, ".svg") == 0) type = "image/svg+xml";
            else if (ext && strcmp(ext, ".png") == 0) type = "image/png";
            else if (ext && strcmp(ext, ".jpg") == 0) type = "image/jpeg";
            send_file(client, full, type);
        }
    }
}

int main(void) {
    int server = socket(AF_INET, SOCK_STREAM, 0);
    if (server < 0) { perror("socket"); return 1; }

    int opt = 1;
    setsockopt(server, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(PORT);

    if (bind(server, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        perror("bind"); close(server); return 1;
    }
    if (listen(server, 20) < 0) {
        perror("listen"); close(server); return 1;
    }

    printf("NovaShop running at http://localhost:%d\n", PORT);
    while (1) {
        int client = accept(server, NULL, NULL);
        if (client >= 0) {
            handle(client);
            close(client);
        }
    }
    close(server);
    return 0;
}
