const products=[
{id:1,name:"Đồng hồ Minimal One",cat:"Phụ kiện",price:2490000,old:3290000,img:"https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=700&q=80",tag:"-24%"},
{id:2,name:"Tai nghe Studio Pro",cat:"Công nghệ",price:1890000,old:2490000,img:"https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=700&q=80",tag:"HOT"},
{id:3,name:"Áo khoác Urban Form",cat:"Thời trang",price:890000,old:1190000,img:"https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=700&q=80",tag:"-25%"},
{id:4,name:"Đèn bàn Ambient",cat:"Nhà cửa",price:690000,old:850000,img:"https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=700&q=80",tag:"NEW"},
{id:5,name:"Kính mát Horizon",cat:"Thời trang",price:590000,old:790000,img:"https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=700&q=80",tag:"-25%"},
{id:6,name:"Loa Bluetooth Arc",cat:"Công nghệ",price:1290000,old:1690000,img:"https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?auto=format&fit=crop&w=700&q=80",tag:"HOT"},
{id:7,name:"Ghế Lounge Soft",cat:"Nhà cửa",price:3190000,old:3990000,img:"https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=700&q=80",tag:"-20%"},
{id:8,name:"Túi Daily Carry",cat:"Phụ kiện",price:790000,old:990000,img:"https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=700&q=80",tag:"NEW"}
];
let cart=JSON.parse(localStorage.getItem("novashop-cart")||"[]");
const money=n=>n.toLocaleString("vi-VN")+"₫";
function render(filter="all",search=""){
 const q=search.toLowerCase();
 const list=products.filter(p=>(filter==="all"||p.cat===filter)&&(!q||p.name.toLowerCase().includes(q)||p.cat.toLowerCase().includes(q)));
 grid.innerHTML=list.map(p=>`<article class="card"><div class="pic"><img src="${p.img}" loading="lazy"><span class="badge">${p.tag}</span><button class="heart">♡</button></div><h3>${p.name}<button class="add" onclick="add(${p.id})">+ Thêm</button></h3><div class="price">${money(p.price)} <span class="old">${money(p.old)}</span></div><small>★★★★★ · Đã bán 120+</small></article>`).join("")||'<div class="empty" style="grid-column:1/-1">Không tìm thấy sản phẩm phù hợp.</div>';
}
function add(id){const p=products.find(x=>x.id===id);const item=cart.find(x=>x.id===id);item?item.qty++:cart.push({id,qty:1});save();toast("Đã thêm vào giỏ hàng");openCart();}
function save(){localStorage.setItem("novashop-cart",JSON.stringify(cart));renderCart();cartCount.textContent=cart.reduce((s,x)=>s+x.qty,0)}
function renderCart(){if(!cart.length){cartItems.innerHTML='<div class="empty">🛒<br><br>Giỏ hàng đang trống.</div>';total.textContent="0₫";return}let sum=0;cartItems.innerHTML=cart.map(x=>{let p=products.find(y=>y.id===x.id);sum+=p.price*x.qty;return `<div class="cart-row"><img src="${p.img}"><div style="flex:1"><strong>${p.name}</strong><small>${money(p.price)}</small><div class="qty"><button onclick="change(${p.id},-1)">−</button>${x.qty}<button onclick="change(${p.id},1)">+</button><button onclick="removeItem(${p.id})" style="margin-left:auto">×</button></div></div></div>`}).join("");total.textContent=money(sum)}
function change(id,d){let x=cart.find(y=>y.id===id);x.qty+=d;if(x.qty<=0)cart=cart.filter(y=>y.id!==id);save()}function removeItem(id){cart=cart.filter(x=>x.id!==id);save()}
function openCart(){drawer.classList.add("open");overlay.classList.add("show")}function closeCart(){drawer.classList.remove("open");overlay.classList.remove("show")}
function toast(t){toastEl.textContent=t;toastEl.classList.add("toast");setTimeout(()=>toastEl.classList.remove("toast"),1800)}
const grid=document.getElementById("grid"),cartCount=document.getElementById("cartCount"),drawer=document.getElementById("drawer"),overlay=document.getElementById("overlay"),cartItems=document.getElementById("cartItems"),total=document.getElementById("total"),toastEl=document.getElementById("toast");
document.querySelectorAll(".filter").forEach(b=>b.onclick=()=>{document.querySelector(".filter.active").classList.remove("active");b.classList.add("active");render(b.dataset.filter,search.value)});
document.querySelectorAll(".cats a").forEach(a=>a.onclick=()=>{let c=a.dataset.cat;document.querySelectorAll(".filter").forEach(b=>b.classList.toggle("active",b.dataset.filter===c));render(c);});
document.getElementById("searchBtn").onclick=()=>render("all",search.value);document.getElementById("search").oninput=e=>render("all",e.target.value);
document.querySelector(".cart-open").onclick=openCart;document.getElementById("closeCart").onclick=closeCart;overlay.onclick=closeCart;
document.querySelector(".checkout").onclick=()=>cart.length?toast("Demo: chuyển sang bước thanh toán"):toast("Giỏ hàng đang trống");
render();save();
let t=8*3600+42*60+19;setInterval(()=>{t--;if(t<0)t=86399;hours.textContent=String(Math.floor(t/3600)).padStart(2,"0");mins.textContent=String(Math.floor(t%3600/60)).padStart(2,"0");secs.textContent=String(t%60).padStart(2,"0")},1000);
